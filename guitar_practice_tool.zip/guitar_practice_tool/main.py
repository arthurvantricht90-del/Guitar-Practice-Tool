import tkinter as tk
import random

from chord_library import CHORDS


def add_transposed_chords(CHORDS, root_chord, shape, new_roots_with_transpose):
    if root_chord not in CHORDS or shape not in CHORDS[root_chord]:
        raise ValueError(f"Root chord '{root_chord}' or shape '{shape}' not found in the dictionary.")

    for quality, chord_shapes in CHORDS[root_chord][shape].items():
        original_chord = chord_shapes[0]
        original_chord_list = original_chord.split(", ")

        for new_root, transpose_by in new_roots_with_transpose:
            transposed_chord = []
            for fret in original_chord_list:
                if fret == 'x':
                    transposed_chord.append(fret)
                else:
                    transposed_chord.append(str(int(fret) + transpose_by))

            transposed_chord_str = ", ".join(transposed_chord)

            if new_root not in CHORDS:
                CHORDS[new_root] = {}
            if shape not in CHORDS[new_root]:
                CHORDS[new_root][shape] = {}
            if quality not in CHORDS[new_root][shape]:
                CHORDS[new_root][shape][quality] = []
            CHORDS[new_root][shape][quality].append(transposed_chord_str)


# Transpose CHORDS
add_transposed_chords(CHORDS, "A", "A shape", [("B",2),("C",3),("D",5),("E",7),("F",8),("G",10),("A",12)])
add_transposed_chords(CHORDS, "C", "C shape", [("D",2),("E",4),("F",5),("G",7),("A",9),("B",11),("C",12)])
add_transposed_chords(CHORDS, "E", "E shape", [("F",1),("G",3),("A",5),("B",7),("C",8),("D",10),("E",12)])
add_transposed_chords(CHORDS, "D", "D shape", [("E",2),("F",3),("G",5),("A",7),("B",9),("C",10),("D",12)])
add_transposed_chords(CHORDS, "G", "G shape", [("A",2),("B",4),("C",5),("D",7),("E",9),("F",10),("D",12)])


def pick_random_chords(CHORDS):
    def is_valid_chord(chord):
        return chord != "x, x, x, x, x, x"

    while True:
        chord1_name, chord1_data = random.choice(list(CHORDS.items()))
        chord1_shape, chord1_variants = random.choice(list(chord1_data.items()))
        chord1_quality, chord1_shapes = random.choice(list(chord1_variants.items()))
        chord1 = chord1_shapes[0]
        if is_valid_chord(chord1):
            break

    while True:
        chord2_name, chord2_data = random.choice(list(CHORDS.items()))
        chord2_shape, chord2_variants = random.choice(list(chord2_data.items()))
        chord2_quality, chord2_shapes = random.choice(list(chord2_variants.items()))
        chord2 = chord2_shapes[0]
        if is_valid_chord(chord2):
            break

    return (
        (f"{chord1_name} {chord1_quality} ({chord1_shape})", chord1),
        (f"{chord2_name} {chord2_quality} ({chord2_shape})", chord2),
    )


# --- Colours ---
BG           = "#1c1c1a"
CARD_BG      = "#252523"
CARD_BORDER  = "#3a3a37"
BOARD_BG     = "#f5efe0"
NUT_COLOR    = "#5a4a2a"
FRET_COLOR   = "#b0a07a"
STRING_COLOR = "#8a7a5a"
DOT_FILL     = "#2c2c2a"
OPEN_STROKE  = "#2c2c2a"
MUTED_COLOR  = "#999999"
FRET_NUM_FG  = "#888888"
LABEL_DIM    = "#666664"
LABEL_LIT    = "#e8e4da"
BTN_BG       = "#2e2e2b"
BTN_FG       = "#e0dbd0"
BTN_ACTIVE   = "#3a3a37"
HINT_FG      = "#555553"
TITLE_FG     = "#c8c4ba"


def draw_chord_diagram(canvas, chord, x_offset, y_offset, card_w, card_h):
    frets = chord.split(", ")
    numeric = [int(f) for f in frets if f != "x"]
    if not numeric:
        return
    lowest = min(numeric)

    # Scale all measurements to fit the card
    usable_w = card_w * 0.62
    usable_h = card_h * 0.72
    STRING_SPACING = usable_w / 5
    FRET_SPACING   = usable_h / 4
    GRID_W = STRING_SPACING * 5
    GRID_H = FRET_SPACING   * 4

    dot_r           = max(5, STRING_SPACING * 0.32)
    open_r          = max(4, STRING_SPACING * 0.26)
    nut_width       = max(2, FRET_SPACING * 0.07)
    fret_num_sz     = max(8, int(FRET_SPACING * 0.22))
    marker_sz       = max(9, int(STRING_SPACING * 0.45))
    fret_num_margin = fret_num_sz * 2.2
    marker_gap      = open_r * 2 + 6

    # Centre diagram within card
    bx = x_offset + (card_w - fret_num_margin - GRID_W) / 2 + fret_num_margin
    by = y_offset + marker_gap + 4

    # Fretboard background
    canvas.create_rectangle(bx, by, bx + GRID_W, by + GRID_H, fill=BOARD_BG, outline="")

    # Fret lines
    for i in range(5):
        y = by + i * FRET_SPACING
        canvas.create_line(bx, y, bx + GRID_W, y,
                           fill=NUT_COLOR if i == 0 else FRET_COLOR,
                           width=nut_width if i == 0 else max(1, nut_width * 0.4))

    # String lines (varying thickness low-to-high)
    for i in range(6):
        x = bx + i * STRING_SPACING
        thickness = max(1, round(1 + (5 - i) * 0.2))
        canvas.create_line(x, by, x, by + GRID_H, fill=STRING_COLOR, width=thickness)

    # Fret number label
    if lowest > 0:
        canvas.create_text(
            bx - fret_num_sz * 0.6, by + FRET_SPACING * 0.5,
            text=str(lowest), font=("Helvetica", fret_num_sz), fill=FRET_NUM_FG, anchor="e"
        )

    # Notes
    for string_idx, fret in enumerate(frets):
        x = bx + string_idx * STRING_SPACING
        if fret == "x":
            canvas.create_text(
                x, by - marker_gap / 2,
                text="✕", font=("Helvetica", marker_sz, "bold"), fill=MUTED_COLOR
            )
        else:
            fret_num = int(fret)
            if fret_num == 0:
                canvas.create_oval(
                    x - open_r, by - marker_gap + 1,
                    x + open_r, by - marker_gap + 1 + open_r * 2,
                    outline=OPEN_STROKE, width=max(1, open_r * 0.25), fill=BOARD_BG
                )
            else:
                row = fret_num - lowest
                y = by + row * FRET_SPACING + FRET_SPACING / 2
                canvas.create_oval(
                    x - dot_r, y - dot_r, x + dot_r, y + dot_r,
                    fill=DOT_FILL, outline=""
                )


def _draw_card(canvas, x1, y1, x2, y2, radius=10):
    r = radius
    canvas.create_polygon(
        x1+r, y1,   x2-r, y1,
        x2,   y1+r, x2,   y2-r,
        x2,   y2,   x1,   y2,
        x1,   y2-r, x1,   y1+r,
        smooth=True, fill=CARD_BG, outline=CARD_BORDER, width=1
    )


def display_chord_names(event=None):
    global current_chords, chord_names_revealed
    if not chord_names_revealed:
        chord1_name, _ = current_chords[0]
        chord2_name, _ = current_chords[1]
        label1.config(text=chord1_name, fg=LABEL_LIT)
        label2.config(text=chord2_name, fg=LABEL_LIT)
        reveal_btn.config(text="Next pair  →")
        chord_names_revealed = True
    else:
        display_chords()


def display_chords(event=None):
    global current_chords, chord_names_revealed
    chord_names_revealed = False
    current_chords = pick_random_chords(CHORDS)
    _redraw()


def _redraw(event=None):
    canvas.delete("all")

    cw = canvas.winfo_width()  or 620
    ch = canvas.winfo_height() or 320
    pad = 10
    gap = 10
    card_w = (cw - pad * 2 - gap) // 2
    card_h = ch - pad * 2

    x1_left  = pad
    x2_left  = pad + card_w
    x1_right = pad + card_w + gap
    x2_right = cw - pad

    _draw_card(canvas, x1_left,  pad, x2_left,  pad + card_h)
    _draw_card(canvas, x1_right, pad, x2_right, pad + card_h)

    draw_chord_diagram(canvas, current_chords[0][1],
                       x_offset=x1_left,  y_offset=pad + 20, card_w=card_w, card_h=card_h)
    draw_chord_diagram(canvas, current_chords[1][1],
                       x_offset=x1_right, y_offset=pad + 20, card_w=card_w, card_h=card_h)

    # Re-apply label visibility state
    if chord_names_revealed:
        label1.config(text=current_chords[0][0], fg=LABEL_LIT)
        label2.config(text=current_chords[1][0], fg=LABEL_LIT)
    else:
        label1.config(text="?", fg=LABEL_DIM)
        label2.config(text="?", fg=LABEL_DIM)


# --- Window setup ---
root = tk.Tk()
root.title("Chord Trainer")
root.configure(bg=BG)
root.resizable(True, True)
root.minsize(620, 420)

# Title bar
title_frame = tk.Frame(root, bg=BG)
title_frame.pack(fill="x", padx=16, pady=(14, 4))
tk.Label(title_frame, text="Chord trainer", font=("Helvetica", 17),
         bg=BG, fg=TITLE_FG).pack(side="left")
tk.Label(title_frame, text="Identify the shapes, then reveal",
         font=("Helvetica", 14), bg=BG, fg=HINT_FG).pack(side="left", padx=(10, 0), pady=(2, 0))

# Canvas — expands to fill available space
canvas = tk.Canvas(root, bg=BG, highlightthickness=0)
canvas.pack(fill="both", expand=True, padx=10)

# Chord name labels
label_frame = tk.Frame(root, bg=BG)
label_frame.pack(fill="x", padx=10, pady=(6, 0))
label1 = tk.Label(label_frame, text="?", font=("Helvetica", 15),
                  bg=BG, fg=LABEL_DIM, width=22, anchor="center")
label1.pack(side="left", expand=True)
label2 = tk.Label(label_frame, text="?", font=("Helvetica", 15),
                  bg=BG, fg=LABEL_DIM, width=22, anchor="center")
label2.pack(side="right", expand=True)

# Buttons
btn_frame = tk.Frame(root, bg=BG)
btn_frame.pack(pady=12)

reveal_btn = tk.Button(
    btn_frame, text="Reveal names",
    font=("Helvetica", 11), bg=BTN_BG, fg=BTN_FG,
    activebackground=BTN_ACTIVE, activeforeground=BTN_FG,
    relief="flat", padx=18, pady=7, cursor="hand2",
    command=display_chord_names
)
reveal_btn.pack(side="left", padx=6)

tk.Button(
    btn_frame, text="New chords",
    font=("Helvetica", 11), bg=BTN_BG, fg=BTN_FG,
    activebackground=BTN_ACTIVE, activeforeground=BTN_FG,
    relief="flat", padx=18, pady=7, cursor="hand2",
    command=display_chords
).pack(side="left", padx=6)

tk.Label(root, text="Space or Enter to reveal / advance",
         font=("Helvetica", 9), bg=BG, fg=HINT_FG).pack(pady=(0, 12))

# Keybindings
root.bind("<Return>", display_chord_names)
root.bind("<space>", display_chord_names)
canvas.bind("<Configure>", _redraw)

chord_names_revealed = False
current_chords = pick_random_chords(CHORDS)
root.mainloop()